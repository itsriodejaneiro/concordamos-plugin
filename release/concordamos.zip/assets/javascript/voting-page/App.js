import React, { useState, useEffect } from "react"
import Form from "./components/Form";

export function App(props) {

	return(
		<>
			<Form />
		</>
	)
}
