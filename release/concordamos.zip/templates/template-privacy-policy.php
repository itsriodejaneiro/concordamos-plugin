<?php get_header(); ?>
<div id="privacy-policy"></div>
<?php get_footer(); ?>
