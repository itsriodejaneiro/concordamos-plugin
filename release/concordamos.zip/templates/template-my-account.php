<?php get_header(); ?>
<div id="concordamos-my-account"></div>
<?php require 'part/navbar-mobile.php'; ?>
<?php get_footer(); ?>
