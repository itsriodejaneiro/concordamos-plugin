<?php
get_header();
?>

<div class="voting-archive-content">
	<?php require 'part/navbar-mobile.php'; ?>
	<div class="render" id="concordamos-voting-archive"></div>
</div>

<?php get_footer(); ?>
